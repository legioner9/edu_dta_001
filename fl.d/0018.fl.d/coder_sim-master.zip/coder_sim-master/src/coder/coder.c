#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>

#include "coder.h"

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    CoderPublic;
    CoderProtected;
    CoderPrivate;
} _Coder;

static_assert(sizeof(_Coder) == sizeof(Coder));
static_assert(sizeof(_Coder) == sizeof(CoderInheritance));

//---------------------------------------------------------------------------------------------------------------------

static char * GetName(void *this)
{
    _Coder *_this = (_Coder*)this;
    return _this->name;
}

static int GetAge(void *this)
{
    _Coder *_this = (_Coder*)this;
    return _this->age;
}

static CoderLevel_e GetLevel(void *this)
{
    const int expSeniorLimit = 180;
    const int expMiddleLimit = 60;

    _Coder *_this = (_Coder*)this;
    CoderLevel_e level;

    if (_this->experience > expSeniorLimit)
    {
        level = CoderLevelSenior;
    }
    else if (_this->experience > expMiddleLimit)
    {
        level = CoderLevelMiddle;
    }
    else
    {
        level = CoderLevelJunior;
    }

    return level;
}

static int GetPower(void *this)
{
    _Coder *_this = (_Coder*)this;
    return _this->GetLevel(_this) + 2;
}

static char * GetLevelStr(void *this)
{
    #define CODER_LEVEL_STR_SIZE    (7)

    static char coderLevelStrArr[][CODER_LEVEL_STR_SIZE] = 
    {
        "junior\0",
        "middle\0",
        "senior\0"
    };

    static_assert((sizeof(coderLevelStrArr) / CODER_LEVEL_STR_SIZE) == CoderLevelsQty);

    _Coder *_this = (_Coder*)this;
    return coderLevelStrArr[_this->GetLevel(_this)];
}

static TaskStatus_e Work(void *this, Task *task)
{
    _Coder *_this = (_Coder*)this;

    while (task->GetStatus(task) == TaskStatusProgress)
    {
        int curPower = _this->GetPower(_this);

        if (_this->DrinkCoffee(_this))
        {
            curPower++;
        }

        task->Develop(task, curPower);
        task->Test(task);

        if (task->GetBugsQty(task) != 0)
        {
            _this->waf += task->GetBugsQty(task);
            task->Fix(task, curPower);
        }
    }

    TaskStatus_e taskStatus = task->GetStatus(task);

    if (taskStatus == TaskStatusDone)
    {
        _this->experience += 5;  
    }
    else if (taskStatus == TaskStatusFail)
    {
        //printf("#!`&*@~?$\n");
        _this->experience += 1;
    }

    return taskStatus;
}

static void Equip(void *this, int cupsOfCoffee)
{
    _Coder *_this = (_Coder*)this;
    _this->cupsOfCoffeeQty += cupsOfCoffee;
}

static bool DrinkCoffee(void* this)
{
    _Coder *_this = (_Coder*)this;
    bool res = _this->cupsOfCoffeeQty != 0;

    if (res)
    {
        _this->cupsOfCoffeeQty--;

        if (_this->cupsOfCoffeeQty == 0)
        {
            printf("coffee is empty\n");
        }
    }

    return res;
}

//---------------------------------------------------------------------------------------------------------------------

Coder * NewCoder(char *name, int age)
{
    _Coder *_this = (_Coder*)malloc(sizeof(_Coder));
    
    if (_this != NULL)
    {
        // Public
        _this->GetName = GetName;
        _this->GetAge = GetAge;
        _this->GetLevel = GetLevel;
        _this->GetLevelStr = GetLevelStr;
        _this->Work = Work;
        _this->DrinkCoffee = DrinkCoffee;
        _this->Equip = (void(*)(void*, ...))Equip;
        
        // Protected
        _this->GetPower = GetPower;
        _this->experience = 0;
        _this->cupsOfCoffeeQty = 0;
        _this->waf = 0;
        
        // Private
        _this->name = (char*)malloc(strlen(name) + 1);
        strcpy(_this->name, name);
        _this->age = age;
    }

    return (Coder*)_this;
}

void DeleteCoder(Coder *this)
{
    _Coder *_this = (_Coder*)this;
    free(_this->name);
    free(_this);
}