#pragma once

#include <stdbool.h>

#include "task.h"

//---------------------------------------------------------------------------------------------------------------------

typedef enum
{
    CoderLevelJunior,
    CoderLevelMiddle,
    CoderLevelSenior,
    CoderLevelsQty
} CoderLevel_e;

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    char *          (*GetName)(void*);
    int             (*GetAge)(void*);
    CoderLevel_e    (*GetLevel)(void*);
    char *          (*GetLevelStr)(void*);
    TaskStatus_e    (*Work)(void*, Task*);
    bool            (*DrinkCoffee)(void*);
    void            (*Equip)(void*, ...);
} CoderPublic;

typedef struct
{
    int (*GetPower)(void*);
    int experience;
    int cupsOfCoffeeQty;
    int waf;
} CoderProtected;

typedef struct
{
    char *name;
    int   age;
} CoderPrivate;

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    CoderPublic;
    CoderProtected;
    char coderPrivateArea[sizeof(CoderPrivate)];
} CoderInheritance;

typedef struct
{
    CoderPublic;
    char coderPrivateArea[sizeof(CoderProtected) + sizeof(CoderPrivate)];
} Coder;

//---------------------------------------------------------------------------------------------------------------------

Coder * NewCoder(char *name, int age);
void DeleteCoder(Coder *this);
