#pragma once

#include "coder.h"

//---------------------------------------------------------------------------------------------------------------------

typedef struct 
{
    void (*Soldering)(void*, int, ...);
} EmbedderPublic;

typedef struct
{
    // Empty
} EmbedderProtected;

typedef struct 
{
    char *specialisation;
    int rosin;
    int solder;
} EmbedderPrivate;

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    Coder;
    EmbedderPublic;
    EmbedderProtected;
    char embedderPrivateArea[sizeof(EmbedderPrivate)];
} EmbedderInheritance;

typedef struct
{
    Coder;
    EmbedderPublic;
    char embedderPrivateArea[sizeof(EmbedderProtected) + sizeof(EmbedderPrivate)];
} Embedder;

//---------------------------------------------------------------------------------------------------------------------

Embedder * NewEmbedder(char *name, int age, char *specialisation);
void DeleteEmbedder(Embedder *this);
