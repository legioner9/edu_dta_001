#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <string.h>

#include "embedder.h"

//---------------------------------------------------------------------------------------------------------------------

typedef struct 
{
    CoderInheritance;
    EmbedderPublic;
    EmbedderProtected;
    EmbedderPrivate;
} _Embedder;

static_assert(sizeof(_Embedder) == sizeof(Embedder));
static_assert(sizeof(_Embedder) == sizeof(EmbedderInheritance));

//---------------------------------------------------------------------------------------------------------------------

static TaskStatus_e Work(void *this, Task *task)
{
    _Embedder *_this = (_Embedder*)this;

    while (task->GetStatus(task) == TaskStatusProgress)
    {
        int curPower = _this->GetPower(_this);

        if (_this->DrinkCoffee(_this))
        {
            curPower++;
        }

        task->Develop(task, curPower);
        task->Test(task);

        if (task->GetBugsQty(task) != 0)
        {
            _this->waf += task->GetBugsQty(task) * 2;
            task->Fix(task, curPower);
        }
    }

    TaskStatus_e taskStatus = task->GetStatus(task);

    if (taskStatus == TaskStatusDone)
    {
        _this->experience += 5;  
    }
    else if (taskStatus == TaskStatusFail)
    {
        //printf("#!`&*@~?$*$#~&^@#$~@\n");
        _this->experience += 1;
    }

    _this->Soldering(_this, 1, 3);
    _this->Soldering(_this, 2, 4, 2);

    return taskStatus;
}

static void Equip(void *this, int cupsOfCoffee, int rosin, int solder)
{
    _Embedder *_this = (_Embedder*)this;
    _this->cupsOfCoffeeQty += cupsOfCoffee;
    _this->rosin += rosin;
    _this->solder += solder;
}

static void Soldering(void *this, int boardTypesQty, ...)
{
    va_list argp;
    va_start(argp, boardTypesQty);

    _Embedder *_this = (_Embedder*)this;
    int totalBoardsQty = 0;

    for (int boardTypeInd = 0; boardTypeInd < boardTypesQty; boardTypeInd++)
    {
        totalBoardsQty += va_arg(argp, int);
    }

    if (_this->rosin != 0 && _this->solder != 0)
    {
        while (_this->rosin && _this->solder != 0 && totalBoardsQty != 0)
        {
            _this->rosin--;
            _this->solder--;
            totalBoardsQty--;
            printf("~");
        }

        _this->experience += 2;

        if (_this->DrinkCoffee(_this))
        {
            _this->experience++;
        }
    }
    va_end(argp);
}

//---------------------------------------------------------------------------------------------------------------------

Embedder * NewEmbedder(char *name, int age, char *specialisation)
{
    Coder *coder = NewCoder(name, age);
    _Embedder *_this = (_Embedder*)realloc(coder, sizeof(_Embedder));

    // Public
    _this->Work = Work;
    _this->Equip = (void(*)(void*, ...))Equip;
    _this->Soldering = Soldering;

    // Private
    _this->specialisation = (char*)malloc(strlen(specialisation) + 1);
    strcpy(_this->specialisation, specialisation);
    _this->rosin = 0;
    _this->solder = 0;

    return (Embedder*)_this;
}

void DeleteEmbedder(Embedder *this)
{
    _Embedder *_this = (_Embedder*)this;
    free(_this->specialisation);
    DeleteCoder((Coder*)_this);  
}