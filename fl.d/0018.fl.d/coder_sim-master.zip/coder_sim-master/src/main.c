#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "coder.h"
#include "embedder.h"

//---------------------------------------------------------------------------------------------------------------------

static void _ShowCoder(Coder *coder)
{
    printf("%s | ", coder->GetName(coder));
    printf("%u | ", coder->GetAge(coder));
    printf("%s\n", coder->GetLevelStr(coder));
}

//---------------------------------------------------------------------------------------------------------------------

int main(void)
{
    srand(time(NULL));

    Coder * coder = NewCoder("Evgeniy", 26);
    Embedder * embedder = NewEmbedder("Dmitriy", 23, "Flux Capacitors Developer");

    Coder * codersTeam[2] = {coder, (Coder*)embedder};

    _ShowCoder(codersTeam[0]);
    _ShowCoder(codersTeam[1]);

    //coder->Equip(coder, 999999);
    //embedder->Equip(embedder, 0, 100, 150);

    for (int i = 0; i < 100; i++)
    {
        Task *task = NewTask(80, 5, 235);
        Coder *curCoder = codersTeam[i % 2];

        TaskStatus_e taskStatus = curCoder->Work(curCoder, task);

        printf("Task #%02u - %s | ", i, taskStatus == TaskStatusDone ? "DONE" : "FAIL");
        _ShowCoder(curCoder);
        DeleteTask(task);
    }

    _ShowCoder(codersTeam[0]);
    _ShowCoder(codersTeam[1]);

    DeleteCoder(coder);
    DeleteEmbedder(embedder);

    return 0;
}