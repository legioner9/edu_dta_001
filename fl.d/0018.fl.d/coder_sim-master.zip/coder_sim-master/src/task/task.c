#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "task.h"

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    TaskPublic;
    TaskProtected;
    TaskPrivate;
} _Task;

static_assert(sizeof(_Task) == sizeof(Task));
static_assert(sizeof(_Task) == sizeof(TaskInheritance));

#define MAX(a, b)   ((a) > (b) ? (a) : (b))
#define MIN(a, b)   ((a) < (b) ? (a) : (b))

//---------------------------------------------------------------------------------------------------------------------

static int _GenerateRand(int max)
{
    float randVal = rand();
    return (int)((randVal / ((float)RAND_MAX + 1)) * (max + 1));
}

static void Develop(void *this, int power)
{
    _Task *_this = (_Task*)this;

    if (_this->curFeaturesCnt < _this->featuresQty)
    {
        _this->curFeaturesCnt += _GenerateRand(power);
        _this->curHiddenBugsCnt += _GenerateRand(3);

        if (_this->curFeaturesCnt > _this->featuresQty)
        {
            _this->curFeaturesCnt = _this->featuresQty;
        }
        _this->timeCnt++;
    }
}

static void Test(void *this)
{
    _Task *_this = (_Task*)this;

    int findedBugs = _GenerateRand(_this->curHiddenBugsCnt);

    _this->curHiddenBugsCnt -= findedBugs;
    _this->curFindedBugsCnt += findedBugs;
    _this->timeCnt++;
}

static void Fix(void *this, int power)
{
    _Task *_this = (_Task*)this;

    _this->curFindedBugsCnt -= _GenerateRand(MIN(power * 2, _this->curFindedBugsCnt));
    _this->curHiddenBugsCnt += _GenerateRand(1);
    _this->timeCnt++;
}

static TaskStatus_e GetStatus(void *this)
{
    _Task *_this = (_Task*)this;
    TaskStatus_e status;

    if (_this->timeCnt <= _this->timeLimit)
    {
        bool done = _this->curFeaturesCnt == _this->featuresQty 
                 && _this->curFindedBugsCnt == 0;
        status = done ? TaskStatusDone : TaskStatusProgress;
    }
    else
    {
        bool done = _this->curFeaturesCnt == _this->featuresQty 
                 && _this->curFindedBugsCnt <= _this->bugsLimit;
        status = done ? TaskStatusDone : TaskStatusFail;
    }
    //printf("  task status %u %u-%u %u\n", _this->curFeaturesCnt, _this->curHiddenBugsCnt, _this->curFindedBugsCnt, _this->timeCnt);
    return status;
}

static int GetBugsQty(void *this)
{
    _Task *_this = (_Task*)this;
    return _this->curFindedBugsCnt;
}

//---------------------------------------------------------------------------------------------------------------------

Task * NewTask(int featuresQty, int bugsLimit, int timeLimit)
{
    _Task *_this = (_Task*)malloc(sizeof(_Task));

    if (_this != NULL)
    {
        // Public
        _this->Develop = Develop;
        _this->Test = Test;
        _this->Fix = Fix;
        _this->GetStatus = GetStatus;
        _this->GetBugsQty = GetBugsQty;

        // Private
        _this->featuresQty = featuresQty;
        _this->bugsLimit = bugsLimit;
        _this->timeLimit = timeLimit;
        _this->curFeaturesCnt = 0;
        _this->curHiddenBugsCnt = 0;
        _this->curFindedBugsCnt = 0;
        _this->timeCnt = 0;
    }

    return (Task*)_this;
}

void DeleteTask(Task *this)
{
    _Task *_this = (_Task*)this;
    free(_this);
}
