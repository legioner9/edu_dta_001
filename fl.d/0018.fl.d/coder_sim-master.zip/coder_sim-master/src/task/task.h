#pragma once

typedef enum
{
    TaskStatusFail,
    TaskStatusProgress,
    TaskStatusDone,
    TaskStatusQty
} TaskStatus_e;

//---------------------------------------------------------------------------------------------------------------------

typedef struct 
{
    void            (*Develop)(void*, int);
    void            (*Test)(void*);
    void            (*Fix)(void*, int);
    TaskStatus_e    (*GetStatus)(void*);
    int             (*GetBugsQty)(void*);
} TaskPublic;

typedef struct
{
    // Empty
} TaskProtected;

typedef struct 
{
    int featuresQty;
    int bugsLimit;
    int timeLimit;
    int curFeaturesCnt;
    int curHiddenBugsCnt;
    int curFindedBugsCnt;
    int timeCnt;
} TaskPrivate;

//---------------------------------------------------------------------------------------------------------------------

typedef struct
{
    TaskPublic;
    TaskProtected;
    char taskPrivateArea[sizeof(TaskPrivate)];
} TaskInheritance;

typedef struct
{
    TaskPublic;
    char taskPrivateArea[sizeof(TaskProtected) + sizeof(TaskPrivate)];
} Task;

//---------------------------------------------------------------------------------------------------------------------

Task * NewTask(int featuresQty, int bugsLimit, int timeLimit);
void DeleteTask(Task *this);
