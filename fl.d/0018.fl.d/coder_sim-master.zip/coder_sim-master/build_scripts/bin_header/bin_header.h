#pragma once

#include <stddef.h>
#include <stdint.h>
#include <assert.h>

#define BIN_HEADER_BEGIN_MAGIC                              (0xD72E5F1A)
#define BIN_HEADER_END_MAGIC                                (0x48EF7EC5)
#define BIN_HEADER_MAJOR_VERSION                            (1)
#define BIN_HEADER_MINOR_VERSION                            (0)
#define BIN_HEADER_PATCH_VERSION                            (0)
#define BIN_HEADER_INVALID_VERSION                          (0xFF)
#define BIN_HEADER_NAMES_SIZE                               (32UL)

#pragma pack(push)
#pragma pack(4)

/**
 * @brief Структура для хранения семантической версии
 *
 */
typedef struct
{
    uint8_t major;          ///< Увеличивается при появлении ломающих (breaking) изменений
    uint8_t minor;          ///< Увеличивается при добавлении новой функциональности
    uint8_t patch;          ///< Увеличивается при внесении исправлений и прочих изменений
    uint8_t RES0[1];
} BIN_HEADER_Version_s;

static_assert(offsetof(BIN_HEADER_Version_s, major)     == 0x00, "");
static_assert(offsetof(BIN_HEADER_Version_s, minor)     == 0x01, "");
static_assert(offsetof(BIN_HEADER_Version_s, patch)     == 0x02, "");
static_assert(offsetof(BIN_HEADER_Version_s, RES0)      == 0x03, "");
static_assert(sizeof(BIN_HEADER_Version_s)              == 0x04, "");

/**
 * @brief Специальная информация о прошивке (резерв)
 *
 */
typedef struct
{
    uint8_t RES0[64];
} BIN_HEADER_FwInfo_s;

/**
 * @brief Информация, полученная из состояния git репозитория
 *
 */
typedef struct
{
    char rev[16];                           ///< Ревизия - наименование последнего тега и часть хеша текущего коммита
    char date[BIN_HEADER_NAMES_SIZE];       ///< Дата и время коммита или дата и время сборки, если в проекте есть изменения
    uint8_t hash[20];                       ///< Полный хеш текущего коммита
} BIN_HEADER_GitInfo_s;

static_assert(offsetof(BIN_HEADER_GitInfo_s, rev)       == 0x00, "");
static_assert(offsetof(BIN_HEADER_GitInfo_s, date)      == 0x10, "");
static_assert(offsetof(BIN_HEADER_GitInfo_s, hash)      == 0x30, "");
static_assert(sizeof(BIN_HEADER_GitInfo_s)              == 0x44, "");

/**
 * @brief Полное описание заголовка
 *
 */
typedef struct
{
    uint32_t beginMagic;                        ///< Начальное магическое число заголовка
    BIN_HEADER_Version_s hdrVer;                ///< Семантическая версия заголовка
    BIN_HEADER_Version_s fwVer;                 ///< Семантическая версия ВПО (формируется из тега git репозитория)
    uint8_t RES1[4];
    char prjName[BIN_HEADER_NAMES_SIZE];        ///< Наименование проекта
    char bcName[BIN_HEADER_NAMES_SIZE];         ///< Наименование конфигурации сборки
    BIN_HEADER_FwInfo_s fwInfo;                 ///< Специальная информация о прошивке (резерв)
    uint8_t RES2[16];
    BIN_HEADER_GitInfo_s gitInfo;               ///< Информация, полученная из состояния git репозитория
    uint8_t RES3[20];
    uint32_t endMagic;                          ///< Завершающее магическое число
    uint32_t crc;                               ///< Контрольная сумма для заголовка
} BIN_HEADER_s;

static_assert(offsetof(BIN_HEADER_s, beginMagic)        == 0x0000, "");
static_assert(offsetof(BIN_HEADER_s, hdrVer)            == 0x0004, "");
static_assert(offsetof(BIN_HEADER_s, fwVer)             == 0x0008, "");
static_assert(offsetof(BIN_HEADER_s, prjName)           == 0x0010, "");
static_assert(offsetof(BIN_HEADER_s, bcName)            == 0x0030, "");
static_assert(offsetof(BIN_HEADER_s, fwInfo)            == 0x0050, "");
static_assert(offsetof(BIN_HEADER_s, gitInfo)           == 0x00A0, "");
static_assert(offsetof(BIN_HEADER_s, endMagic)          == 0x00F8, "");
static_assert(offsetof(BIN_HEADER_s, crc)               == 0x00FC, "");
static_assert(sizeof(BIN_HEADER_s)                      == 0x0100, "");

#pragma pack(pop)

/**
 * @brief Возвращает указатель на заголовок
 *
 * @return Указатель на заголовок
 */
BIN_HEADER_s const * BIN_HEADER_GetHeader(void);
