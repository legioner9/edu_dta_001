#include "bin_header.h"

static const BIN_HEADER_s __attribute__((section(".header"))) binHeader =
{
    .beginMagic = BIN_HEADER_BEGIN_MAGIC,
    .hdrVer.major = BIN_HEADER_MAJOR_VERSION,
    .hdrVer.minor = BIN_HEADER_MINOR_VERSION,
    .hdrVer.patch = BIN_HEADER_PATCH_VERSION,
    .fwVer.major = BIN_HEADER_INVALID_VERSION,
    .fwVer.minor = BIN_HEADER_INVALID_VERSION,
    .fwVer.patch = BIN_HEADER_INVALID_VERSION,
    .prjName = BUILDER_PRJ_NAME,
    .bcName = BUILDER_BC_NAME,
    .endMagic = BIN_HEADER_END_MAGIC,
};

BIN_HEADER_s const * BIN_HEADER_GetHeader(void)
{
    return &binHeader;
}
