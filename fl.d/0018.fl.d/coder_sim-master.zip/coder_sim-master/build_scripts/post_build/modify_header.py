import re
import datetime
import subprocess
import argparse
from ctypes import Structure, c_uint32, c_uint8, c_char, c_ubyte, sizeof

#--------------------------------------

BIN_HEADER_NAMES_SIZE = 32

class BIN_HEADER_Version_s(Structure):
    _pack_ = 4
    _fields_ = [
        ("major", c_uint8),
        ("minor", c_uint8),
        ("patch", c_uint8),
        ("RES0", (c_uint8 * 1)),
    ]

assert BIN_HEADER_Version_s.major.offset        == 0x00
assert BIN_HEADER_Version_s.minor.offset        == 0x01
assert BIN_HEADER_Version_s.patch.offset        == 0x02
assert BIN_HEADER_Version_s.RES0.offset         == 0x03
assert sizeof(BIN_HEADER_Version_s)             == 0x04

class BIN_HEADER_FwInfo_s(Structure):
    _pack_ = 4
    _fields_ = [
        ("RES0", (c_uint8 * 64)),
    ]

class BIN_HEADER_GitInfo_s(Structure):
    _pack_ = 4
    _fields_ = [
        ("rev", c_char * 16),
        ("date", c_char * BIN_HEADER_NAMES_SIZE),
        ("hash", c_uint8 * 20),
    ]

assert BIN_HEADER_GitInfo_s.rev.offset          == 0x00
assert BIN_HEADER_GitInfo_s.date.offset         == 0x10
assert BIN_HEADER_GitInfo_s.hash.offset         == 0x30
assert sizeof(BIN_HEADER_GitInfo_s)             == 0x44

class BIN_HEADER_s(Structure):
    _pack_ = 4
    _fields_ = [
        ("beginMagic", c_uint32),
        ("hdrVer", BIN_HEADER_Version_s),
        ("fwVer", BIN_HEADER_Version_s),
        ("RES1", c_uint8 * 4),
        ("prjName", c_char * BIN_HEADER_NAMES_SIZE),
        ("bcName", c_char * BIN_HEADER_NAMES_SIZE),
        ("fwInfo", BIN_HEADER_FwInfo_s),
        ("RES2", c_uint8 * 16),
        ("gitInfo", BIN_HEADER_GitInfo_s),
        ("RES3", c_uint8 * 20),
        ("endMagic", c_uint32),
        ("crc", c_uint32),
    ]

assert BIN_HEADER_s.beginMagic.offset           == 0x0000
assert BIN_HEADER_s.hdrVer.offset               == 0x0004
assert BIN_HEADER_s.fwVer.offset                == 0x0008
assert BIN_HEADER_s.prjName.offset              == 0x0010
assert BIN_HEADER_s.bcName.offset               == 0x0030
assert BIN_HEADER_s.fwInfo.offset               == 0x0050
assert BIN_HEADER_s.gitInfo.offset              == 0x00A0
assert BIN_HEADER_s.endMagic.offset             == 0x00F8
assert BIN_HEADER_s.crc.offset                  == 0x00FC
assert sizeof(BIN_HEADER_s)                     == 0x0100


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--file-path', help='Path to bin file', action='store', required=True)
    parser.add_argument('-d', '--objdump', help='Path to objdump', action='store', required=True)
    args = parser.parse_args()

    file_path = args.file_path
    elf_file_path = file_path[:file_path.rfind('.')] + '.elf'
    bin_file_path = file_path[:file_path.rfind('.')] + '.bin'
    sections = subprocess.run([args.objdump, '-h', elf_file_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout

    modify_enable = False
    for s in sections.split('\n'):
        if ' .header ' in s:
            modify_enable = True
            section_params = s.split()
            header_size = int(section_params[2], 16)
            header_offset = int(section_params[4], 16) & 0xFFFF
            if (header_size > 0x1000) or (header_offset > 0x1000):
                print('Check linker script or modify_header script')
                exit(1)

    if modify_enable:
        try:
            text = subprocess.run(['git', 'status'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False).stderr
            modify_enable = not ('not a git repository' in text)
        except:
            print('Git not found')
            modify_enable = False

    if modify_enable:
        print(f'"Modify header: {bin_file_path}"')
        bin_file = open(bin_file_path, "rb")
        bin_image = bytearray(bin_file.read())
        header_struct = BIN_HEADER_s.from_buffer_copy(bin_image, header_offset)

        dirty_flag = 'Changes not staged for commit:' in subprocess.run(['git', 'status'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout

        revision = subprocess.run(['git', 'describe', '--tags', '--dirty=-x', '--always'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout
        if re.match(r'\d+\.\d+\.\d+', revision):
            revision = revision.replace('\n', '')
            revision = revision.replace('\r', '')
            revision = revision[:BIN_HEADER_GitInfo_s.rev.size - 1]
            header_struct.gitInfo.rev = revision.encode(encoding="utf-8")
            ver_list = re.split('[.|-]', revision)
            if not dirty_flag and len(ver_list) == 3:
                header_struct.fwVer.major = int(ver_list[0])
                header_struct.fwVer.minor = int(ver_list[1])
                header_struct.fwVer.patch = int(ver_list[2])

        if dirty_flag:
            date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' (dirty)'
        else:
            date = subprocess.run(['git', 'show', '-s', '--format=%ci'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout

        date = date.replace('\n', '')
        date = date.replace('\r', '')
        header_struct.gitInfo.date = date.encode(encoding="utf-8")

        hash = subprocess.run(['git', 'rev-parse', 'HEAD'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout
        hash = hash.replace('\n', '')
        hash = hash.replace('\r', '')
        hash = bytearray.fromhex(hash)
        header_struct.gitInfo.hash = (c_ubyte * 20).from_buffer_copy(hash)

        bin_image[header_offset : header_offset + header_size] = bytearray(header_struct)
        with open(bin_file_path, "wb") as f:
            f.write(bin_image)
