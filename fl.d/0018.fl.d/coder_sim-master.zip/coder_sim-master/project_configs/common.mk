include build_scripts/global.mk
# Параметры проекта, общие для всех конфигураций сборки

# Выбор компиляции
ifeq ($(OS),Windows_NT)
	GCC     := i686-w64-mingw32-gcc
	G++     := i686-w64-mingw32-g++
	SIZE    := size
	OBJDUMP := objdump
	OBJCOPY := objcopy
else
	GCC     := gcc
	G++     := g++
	SIZE    := size
	OBJDUMP := objdump
	OBJCOPY := objcopy
endif

# Название проекта
PRJ_NAME := coder_sim

# Расширение исполняемого файла (.elf, .exe,  и др.)
ifeq ($(OS),Windows_NT)
	PRJ_OUT_EXTENSION := .exe
else
	PRJ_OUT_EXTENSION := 
endif

# Флаги компиляции
PRJ_CFLAGS := \
-O1

# Флаги линкера
PRJ_LFLAGS := \

# Дефайны
PRJ_DEFINES := \

# Пути к заголовочным файлам
PRJ_INC_PATHS := \
src/coder \
src/embedder \
src/task \

# Пути к файлам с исходным кодом
PRJ_SRC_PATHS := \
src \

# Пути к скомпилированным библиотекам
PRJ_LIB_PATHS := \

# Наименования библиотек
PRJ_LIBRARIES := \

# LD-скрипт
PRJ_LINKER_SCRIPT := \

PRJ_GCC_DEF := \

# Прочие файлы, при изменении которых необходимо перезапускать сборку
PRJ_OTHER_DEPS := \
