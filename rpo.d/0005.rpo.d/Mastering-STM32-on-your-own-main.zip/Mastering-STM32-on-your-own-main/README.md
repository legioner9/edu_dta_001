# Osvoenie STM32 samostoyatel'no
 Sources for studying STM32 microcontrollers.
 Можно купить только в 3-х официальных магазинах:
 1. https://ozon.ru/t/Bmzbl0P
 2. https://wildberries.ru/catalog/239464978/detail.aspx
 3. https://aliexpress.ru/item/1005006774654765.html

 Продолжение данной книги "Освоение STM32 самостоятельно #2":
 https://www.ozon.ru/product/osvoenie-stm32-samostoyatelno-2-2187992752
 Остерегайтесь подделок и перепродажников!!!
